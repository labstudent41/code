class Properties {
}
