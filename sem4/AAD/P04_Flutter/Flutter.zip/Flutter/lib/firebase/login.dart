import 'package:flutter/material.dart';
import 'logincomponent.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return LoginComponent();
  }
}
