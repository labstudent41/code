package com.example.database

import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var add:Button
    private lateinit var print:Button
    private lateinit var edit1:EditText
    private lateinit var edit2:EditText
    private lateinit var t1:TextView
    private lateinit var t2:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        add=findViewById(R.id.add)
        print=findViewById(R.id.print)
        edit1=findViewById(R.id.edit1)
        edit2=findViewById(R.id.edit2)
        t1=findViewById(R.id.t1)
        t2=findViewById(R.id.t2)
        add.setOnClickListener{
            val db=DBHelper(this,null)
            val name=edit1.text.toString()
            val age=edit2.text.toString()

            db.addName(name,age)
            Toast.makeText(this,name+"added to database",Toast.LENGTH_LONG).show()
            edit1.text.clear()
            edit2.text.clear()

        }
        print.setOnClickListener {
            val db = DBHelper(this, null)
            val cursor = db.getName()
            cursor!!.moveToFirst()
            t1.append(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.NAME_COL)) + "\n")
            t2.append(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.AGE_COL)) + "\n")

            while (cursor.moveToNext()) {
                t1.append(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.NAME_COL)) + "\n")
                t2.append(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.AGE_COL)) + "\n")
            }
            cursor.close()
        }
    }
}