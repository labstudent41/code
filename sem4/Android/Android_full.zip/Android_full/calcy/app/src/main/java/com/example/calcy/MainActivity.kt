package com.example.calcy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Adapter
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    private lateinit var gen:RadioGroup
    private lateinit var gen_s:RadioButton
    private lateinit var cs:Spinner
    private lateinit var show:TextView
    private lateinit var name:EditText
    private lateinit var b1:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        gen=findViewById(R.id.rg)
        cs=findViewById(R.id.spinner)
        name=findViewById(R.id.edit1)
        show=findViewById(R.id.text1)
        b1=findViewById(R.id.bt1)

        val sap=ArrayAdapter.createFromResource(this,R.array.spinner_options,android.R.layout.simple_spinner_item)
        sap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        cs.adapter=sap

        b1.setOnClickListener{
            val s=gen.checkedRadioButtonId
            gen_s=findViewById(s)
            val result="Name: ${name.text.toString()} \nGender: ${gen_s.text.toString()} \nCourse: ${cs.selectedItem.toString()} "
            show.text=result
        }

    }
}