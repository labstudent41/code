'strings.xml' goes in app/src/main/res/values/
