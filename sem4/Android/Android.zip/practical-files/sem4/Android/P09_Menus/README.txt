'omenu.xml' goes in app/src/main/res/menu/
