Get your favourite music from the internet and rename it to 'music'
Then copy it to /app/src/main/raw/
